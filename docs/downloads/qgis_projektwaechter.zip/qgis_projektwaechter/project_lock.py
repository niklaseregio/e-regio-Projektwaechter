from qgis.PyQt.QtWidgets import QLabel, QWidget, QHBoxLayout, QDialog, QPushButton, QVBoxLayout
from qgis.PyQt.QtCore import QObject, QTimer, Qt, QEvent
from qgis.PyQt.QtGui import QKeySequence
from qgis.core import QgsProject, QgsApplication, QgsMessageLog, Qgis

import os
import json
import uuid
import glob
import getpass
import socket
from datetime import datetime
from typing import Optional, Tuple, List, Dict


def _ga(obj, name, default=None):
    try:
        return getattr(obj, name)
    except (AttributeError, TypeError):
        return default


def _deep(obj, *names, default=None):
    cur = obj
    for n in names:
        cur = _ga(cur, n, None)
        if cur is None:
            return default
    return cur


_WT = _ga(Qt, "WindowType", Qt)
_WM = _ga(Qt, "WindowModality", Qt)
_AF = _ga(Qt, "AlignmentFlag", Qt)
_K = _ga(Qt, "Key", Qt)
_TIF = _ga(Qt, "TextInteractionFlag", Qt)

_EVENT_KEYPRESS = _deep(QEvent, "Type", "KeyPress", default=_ga(QEvent, "KeyPress"))

_DLG_ACCEPTED = _deep(QDialog, "DialogCode", "Accepted", default=_ga(QDialog, "Accepted", 1))
_DLG_REJECTED = _deep(QDialog, "DialogCode", "Rejected", default=_ga(QDialog, "Rejected", 0))

_QKS_SAVE = _deep(QKeySequence, "StandardKey", "Save", default=_ga(QKeySequence, "Save"))
_QKS_SAVEAS = _deep(QKeySequence, "StandardKey", "SaveAs", default=_ga(QKeySequence, "SaveAs"))

_LOG_WARNING = _deep(Qgis, "MessageLevel", "Warning", default=_ga(Qgis, "Warning"))
_LOG_INFO = _deep(Qgis, "MessageLevel", "Info", default=_ga(Qgis, "Info"))


class SaveKeyFilter(QObject):
    def __init__(self, plugin):
        super().__init__()
        self.plugin = plugin

    def eventFilter(self, obj, event):
        if event.type() == _EVENT_KEYPRESS:
            if self.plugin.read_only_mode or self.plugin.reload_required:
                if event.matches(_QKS_SAVE) or event.matches(_QKS_SAVEAS):
                    return True
        return False


class LockWaitDialog(QDialog):
    def __init__(self, parent, user, opened, seconds=5):
        super().__init__(parent)
        self._remaining = int(seconds)
        self._user = user or "Unbekannt"
        self._opened = opened or "Unbekannt"
        self._choice = None

        self.setWindowTitle("Projekt gesperrt")
        self.setWindowModality(_WM.ApplicationModal)

        self.setWindowFlags(
            _WT.Dialog
            | _WT.CustomizeWindowHint
            | _WT.WindowTitleHint
            | _WT.WindowStaysOnTopHint
        )

        self.label = QLabel(f"Projekt wird von {self._user} bearbeitet.\nGeöffnet: {self._opened}")
        self.label.setTextInteractionFlags(_TIF.TextSelectableByMouse)

        self.countdown = QLabel("")
        self.countdown.setStyleSheet("color: #b00000; font-weight: 600;")

        self.btn_open = QPushButton("")
        self.btn_open.setEnabled(False)

        self.btn_close = QPushButton("Projekt schließen")

        self.btn_close.clicked.connect(self._on_close)
        self.btn_open.clicked.connect(self._on_open)

        layout = QVBoxLayout(self)
        layout.addWidget(self.label)
        layout.addSpacing(8)
        layout.addWidget(self.countdown)
        layout.addSpacing(8)
        layout.addWidget(self.btn_open)
        layout.addWidget(self.btn_close)

        self._timer = QTimer(self)
        self._timer.setInterval(1000)
        self._timer.timeout.connect(self._tick)

        self._update_texts()
        self._timer.start()

    def _update_texts(self):
        if self._remaining > 0:
            self.countdown.setText(f"Bitte warten: {self._remaining} s")
            self.btn_open.setText(f"Schreibgeschützt öffnen (in {self._remaining} s)")
            self.btn_open.setEnabled(False)
        else:
            self.countdown.setText("")
            self.btn_open.setText("Schreibgeschützt öffnen")
            self.btn_open.setEnabled(True)

    def _tick(self):
        self._remaining -= 1
        if self._remaining <= 0:
            self._remaining = 0
            self._timer.stop()
        self._update_texts()

    def _on_open(self):
        if self._remaining > 0:
            return
        self._choice = "open"
        self.done(_DLG_ACCEPTED)

    def _on_close(self):
        self._choice = "close"
        self.done(_DLG_REJECTED)

    def closeEvent(self, event):
        event.ignore()

    def keyPressEvent(self, event):
        if event.key() in (_K.Key_Escape,):
            event.ignore()
            return
        super().keyPressEvent(event)

    @property
    def choice(self):
        return self._choice


class ProjectLockPlugin(QObject):
    LOCK_SUFFIX = ".projectlockplugin.lock"
    PRESENCE_PREFIX = ".projectlockplugin.presence."
    PRESENCE_SUFFIX = ".json"

    RED_BLINK_INTERVAL_MS = 600
    OWNER_BLINK_INTERVAL_MS = 1400

    HEARTBEAT_INTERVAL_MS = 3000
    PRESENCE_STALE_SECONDS = 12

    def __init__(self, iface):
        super().__init__()
        self.iface = iface

        self.session_id = uuid.uuid4().hex
        self.lock_file = None
        self.presence_file = None

        self.read_only_mode = False
        self.is_owner = False
        self.reload_required = False

        self.lock_user = None
        self.lock_opened = None
        self._lock_dialog_shown = False

        self._indicator_widget = None
        self._dot = None
        self._text = None

        self._blink_on = False
        self._blink_mode = "none"
        self._blink_color = None
        self._blink_box_static = None

        self.anim_timer = QTimer()
        self.anim_timer.timeout.connect(self._anim_tick)

        self.heartbeat_timer = QTimer()
        self.heartbeat_timer.setInterval(self.HEARTBEAT_INTERVAL_MS)
        self.heartbeat_timer.timeout.connect(self._heartbeat_tick)

        self._key_filter = SaveKeyFilter(self)

    def _log(self, msg, level=_LOG_WARNING):
        QgsMessageLog.logMessage(str(msg), "qgis_projektwaechter", level)

    def initGui(self):
        QgsProject.instance().readProject.connect(self._on_project_read)
        QgsProject.instance().cleared.connect(self.close_project)

        self._setup_indicator()

        try:
            self.iface.mainWindow().installEventFilter(self._key_filter)
        except (AttributeError, RuntimeError, TypeError) as e:
            self._log(e, _LOG_INFO)

        try:
            app = QgsApplication.instance()
            if app:
                app.aboutToQuit.connect(self.close_project)
        except (AttributeError, RuntimeError, TypeError) as e:
            self._log(e, _LOG_INFO)

        self._apply_save_state()

    def unload(self):
        self.close_project()

        try:
            QgsProject.instance().readProject.disconnect(self._on_project_read)
        except (TypeError, RuntimeError) as e:
            self._log(e, _LOG_INFO)

        try:
            QgsProject.instance().cleared.disconnect(self.close_project)
        except (TypeError, RuntimeError) as e:
            self._log(e, _LOG_INFO)

        try:
            self.iface.mainWindow().removeEventFilter(self._key_filter)
        except (AttributeError, RuntimeError, TypeError) as e:
            self._log(e, _LOG_INFO)

        try:
            if self._indicator_widget:
                sb = self.iface.mainWindow().statusBar()
                if sb:
                    sb.removeWidget(self._indicator_widget)
        except (AttributeError, RuntimeError, TypeError) as e:
            self._log(e, _LOG_INFO)

    def _on_project_read(self):
        QTimer.singleShot(0, self.open_project)

    def _project_path(self):
        return QgsProject.instance().fileName() or ""

    def _lock_path(self, project_path):
        return project_path + self.LOCK_SUFFIX

    def _presence_path(self, project_path, session_id):
        return project_path + self.PRESENCE_PREFIX + session_id + self.PRESENCE_SUFFIX

    def _presence_glob(self, project_path):
        return project_path + self.PRESENCE_PREFIX + "*" + self.PRESENCE_SUFFIX

    def _setup_indicator(self):
        if self._indicator_widget:
            return

        self._indicator_widget = QWidget()
        layout = QHBoxLayout(self._indicator_widget)
        layout.setContentsMargins(8, 3, 8, 3)
        layout.setSpacing(8)

        self._dot = QLabel()
        self._dot.setFixedSize(12, 12)
        self._dot.setAlignment(_AF.AlignCenter)

        self._text = QLabel("")
        self._text.setStyleSheet("color: #222; font-weight: 600;")

        layout.addWidget(self._dot)
        layout.addWidget(self._text)
        self._indicator_widget.setVisible(False)

        try:
            sb = self.iface.mainWindow().statusBar()
            if sb:
                sb.addPermanentWidget(self._indicator_widget)
        except (AttributeError, RuntimeError, TypeError) as e:
            self._log(e, _LOG_INFO)
            self._indicator_widget = None
            self._dot = None
            self._text = None

    def _set_indicator_visible(self, visible: bool):
        if self._indicator_widget:
            self._indicator_widget.setVisible(bool(visible))

    def _set_indicator_text(self, text: str, color_hex: str):
        if self._text:
            self._text.setText(text or "")
            self._text.setStyleSheet(f"color: {color_hex}; font-weight: 600;")

    def _set_box_style(self, border_hex: str, bg_hex: str):
        if self._indicator_widget:
            self._indicator_widget.setStyleSheet(
                f"border: 2px solid {border_hex}; border-radius: 6px; background-color: {bg_hex};"
            )

    def _set_dot_style(self, dot_hex: str):
        if self._dot:
            self._dot.setStyleSheet(f"border-radius: 6px; background-color: {dot_hex};")

    def _apply_save_state(self):
        blocked = self.read_only_mode or self.reload_required

        try:
            a = self.iface.actionSaveProject()
            if a:
                a.setEnabled(not blocked)
        except (AttributeError, RuntimeError, TypeError) as e:
            self._log(e, _LOG_INFO)

        try:
            a = self.iface.actionSaveProjectAs()
            if a:
                a.setEnabled(not blocked)
        except (AttributeError, RuntimeError, TypeError) as e:
            self._log(e, _LOG_INFO)

    def _set_modes(self, read_only: bool, reload_required: bool, is_owner: bool):
        self.read_only_mode = bool(read_only)
        self.reload_required = bool(reload_required)
        self.is_owner = bool(is_owner)
        self._apply_save_state()

    def _read_lock_info(self, path):
        try:
            with open(path, "r", encoding="utf-8") as f:
                return json.load(f)
        except (OSError, json.JSONDecodeError, ValueError) as e:
            self._log(f"read lock failed: {e}", _LOG_INFO)
            return None

    def _read_presence_info(self, path):
        try:
            with open(path, "r", encoding="utf-8") as f:
                return json.load(f)
        except (OSError, json.JSONDecodeError, ValueError):
            return None

    def _lock_user_from_info(self, info):
        if isinstance(info, dict):
            u = info.get("user")
            if u:
                return u
        return "Unbekannt"

    def _lock_opened_from_info(self, info):
        if isinstance(info, dict):
            o = info.get("opened")
            if o:
                return o
        return "Unbekannt"

    def _create_lock_atomically(self, path):
        payload = {
            "session_id": self.session_id,
            "user": getpass.getuser(),
            "host": socket.gethostname(),
            "pid": os.getpid(),
            "opened": datetime.now().strftime("%d.%m.%Y %H:%M:%S"),
        }
        fd = os.open(path, os.O_CREAT | os.O_EXCL | os.O_WRONLY)
        with os.fdopen(fd, "w", encoding="utf-8") as f:
            json.dump(payload, f, ensure_ascii=False, indent=2)

    def _write_presence(self, path, mode):
        payload = {
            "session_id": self.session_id,
            "user": getpass.getuser(),
            "host": socket.gethostname(),
            "pid": os.getpid(),
            "mode": mode,
            "seen": datetime.now().strftime("%d.%m.%Y %H:%M:%S"),
        }
        try:
            fd = os.open(path, os.O_CREAT | os.O_EXCL | os.O_WRONLY)
            with os.fdopen(fd, "w", encoding="utf-8") as f:
                json.dump(payload, f, ensure_ascii=False, indent=2)
        except FileExistsError:
            try:
                with open(path, "w", encoding="utf-8") as f:
                    json.dump(payload, f, ensure_ascii=False, indent=2)
            except (OSError, TypeError, ValueError) as e:
                self._log(f"presence overwrite failed: {e}", _LOG_INFO)
        except (OSError, TypeError, ValueError) as e:
            self._log(f"presence create failed: {e}", _LOG_INFO)

    def _touch_presence(self):
        if not self.presence_file:
            return
        try:
            os.utime(self.presence_file, None)
        except OSError:
            project_path = self._project_path()
            if not project_path:
                return
            self.presence_file = self._presence_path(project_path, self.session_id)
            self._write_presence(self.presence_file, "owner" if self.is_owner else "viewer")

    def _remove_lock_if_ours(self):
        if not self.lock_file or not os.path.exists(self.lock_file):
            return
        info = self._read_lock_info(self.lock_file)
        if isinstance(info, dict) and info.get("session_id") == self.session_id:
            try:
                os.remove(self.lock_file)
            except OSError as e:
                self._log(f"remove lock failed: {e}", _LOG_INFO)

    def _remove_presence_if_ours(self):
        if self.presence_file and os.path.exists(self.presence_file):
            try:
                os.remove(self.presence_file)
            except OSError as e:
                self._log(f"remove presence failed: {e}", _LOG_INFO)

    def _list_active_observers(self, project_path) -> List[Dict]:
        now_ts = datetime.now().timestamp()
        observers = []

        for p in glob.glob(self._presence_glob(project_path)):
            if self.presence_file and os.path.normpath(p) == os.path.normpath(self.presence_file):
                continue

            try:
                age = now_ts - os.path.getmtime(p)
            except OSError:
                continue

            if age > self.PRESENCE_STALE_SECONDS:
                try:
                    os.remove(p)
                except OSError as e:
                    self._log(f"remove stale presence failed: {e}", _LOG_INFO)
                continue

            info = self._read_presence_info(p) or {}
            if isinstance(info, dict) and info.get("mode") == "viewer":
                user = info.get("user") or "Unbekannt"
                host = info.get("host") or ""
                try:
                    mtime = os.path.getmtime(p)
                except OSError:
                    mtime = 0
                observers.append({"user": user, "host": host, "mtime": mtime})

        observers.sort(key=lambda x: x.get("mtime", 0), reverse=True)
        return observers

    def _set_anim(self, mode: str, color_hex: str, interval_ms: int, box_static: Optional[Tuple[str, str]]):
        self._blink_mode = mode
        self._blink_color = color_hex
        self._blink_box_static = box_static
        self._blink_on = False
        if mode == "none":
            if self.anim_timer.isActive():
                self.anim_timer.stop()
            return
        self.anim_timer.setInterval(interval_ms)
        if not self.anim_timer.isActive():
            self.anim_timer.start()
        self._anim_tick()

    def _anim_tick(self):
        if self._blink_mode == "none":
            return
        self._blink_on = not self._blink_on

        if self._blink_mode == "red_box":
            if self._blink_on:
                self._set_dot_style(self._blink_color)
                self._set_box_style(self._blink_color, "#fff0f0")
            else:
                self._set_dot_style("transparent")
                self._set_box_style("transparent", "transparent")
            return

        if self._blink_mode == "dot_only":
            if self._blink_box_static:
                border, bg = self._blink_box_static
                self._set_box_style(border, bg)
            if self._blink_on:
                self._set_dot_style(self._blink_color)
            else:
                self._set_dot_style("transparent")
            return

    def _apply_owner_indicator(self, observers: List[Dict]):
        self._set_indicator_visible(True)

        base_text = "Bearbeitung aktiv"
        if observers:
            o = observers[0]
            name = o.get("user") or "Unbekannt"
            host = o.get("host") or ""
            who = f"{name}@{host}" if host else name
            extra = ""
            if len(observers) > 1:
                extra = f" (+{len(observers) - 1})"
            base_text = f"Bearbeitung aktiv (Beobachter: {who}{extra})"

        self._set_indicator_text(base_text, "#222")
        self._set_anim("dot_only", "#0a8f3a", self.OWNER_BLINK_INTERVAL_MS, ("#0a8f3a", "#eefaf1"))

    def _apply_viewer_locked_indicator(self, user: str):
        self._set_indicator_visible(True)
        self._set_indicator_text(f"Projekt wird von {user} bearbeitet", "#b00000")
        self._set_anim("red_box", "#d00000", self.RED_BLINK_INTERVAL_MS, None)

    def _apply_reload_required_indicator(self):
        self._set_indicator_visible(True)
        self._set_indicator_text("Projekt schließen und neu öffnen um bearbeiten zu können", "#b00000")
        self._set_anim("red_box", "#d00000", self.RED_BLINK_INTERVAL_MS, None)

    def _show_lock_dialog_once(self):
        if self._lock_dialog_shown:
            return
        self._lock_dialog_shown = True
        dlg = LockWaitDialog(self.iface.mainWindow(), self.lock_user, self.lock_opened, seconds=5)
        exec_fn = getattr(dlg, "exec", None) or getattr(dlg, "exec_", None)
        exec_fn()
        if dlg.choice == "close":
            QgsProject.instance().clear()

    def _heartbeat_tick(self):
        project_path = self._project_path()
        if not project_path or not self.presence_file:
            return

        self._touch_presence()
        self._apply_save_state()

        if self.is_owner and not self.read_only_mode and not self.reload_required:
            observers = self._list_active_observers(project_path)
            self._apply_owner_indicator(observers)
            return

        if self.read_only_mode:
            if self.lock_file and os.path.exists(self.lock_file):
                info = self._read_lock_info(self.lock_file)
                self.lock_user = self._lock_user_from_info(info)
                self.lock_opened = self._lock_opened_from_info(info)
                self._apply_viewer_locked_indicator(self.lock_user)
                return

            self._set_modes(False, True, False)
            self._apply_reload_required_indicator()
            return

        if self.reload_required:
            self._apply_reload_required_indicator()

    def open_project(self):
        project_path = self._project_path()
        if not project_path:
            self.lock_file = None
            self.presence_file = None
            self.lock_user = None
            self.lock_opened = None
            self._lock_dialog_shown = False
            self._set_modes(False, False, False)
            self._set_anim("none", "", 0, None)
            self._set_indicator_visible(False)
            if self.heartbeat_timer.isActive():
                self.heartbeat_timer.stop()
            return

        self.lock_file = self._lock_path(project_path)
        self.presence_file = self._presence_path(project_path, self.session_id)

        self.lock_user = None
        self.lock_opened = None
        self._lock_dialog_shown = False

        try:
            self._create_lock_atomically(self.lock_file)
            self._set_modes(False, False, True)
            self._write_presence(self.presence_file, "owner")
            if not self.heartbeat_timer.isActive():
                self.heartbeat_timer.start()
            observers = self._list_active_observers(project_path)
            self._apply_owner_indicator(observers)
            return

        except FileExistsError:
            info = self._read_lock_info(self.lock_file)
            if isinstance(info, dict) and info.get("session_id") == self.session_id:
                self._set_modes(False, False, True)
                self._write_presence(self.presence_file, "owner")
                if not self.heartbeat_timer.isActive():
                    self.heartbeat_timer.start()
                observers = self._list_active_observers(project_path)
                self._apply_owner_indicator(observers)
                return

            self.lock_user = self._lock_user_from_info(info)
            self.lock_opened = self._lock_opened_from_info(info)
            self._set_modes(True, False, False)
            self._write_presence(self.presence_file, "viewer")
            if not self.heartbeat_timer.isActive():
                self.heartbeat_timer.start()
            self._apply_viewer_locked_indicator(self.lock_user)
            self._show_lock_dialog_once()
            return

        except (OSError, PermissionError) as e:
            self._log(f"open_project failed: {e}")
            self.lock_user = "Unbekannt"
            self.lock_opened = "Unbekannt"
            self._set_modes(True, False, False)
            self._write_presence(self.presence_file, "viewer")
            if not self.heartbeat_timer.isActive():
                self.heartbeat_timer.start()
            self._apply_viewer_locked_indicator(self.lock_user)
            self._show_lock_dialog_once()

    def close_project(self):
        if self.heartbeat_timer.isActive():
            self.heartbeat_timer.stop()
        if self.anim_timer.isActive():
            self.anim_timer.stop()

        self._remove_presence_if_ours()
        if self.is_owner and not self.read_only_mode and not self.reload_required:
            self._remove_lock_if_ours()

        self.lock_file = None
        self.presence_file = None
        self.lock_user = None
        self.lock_opened = None
        self._lock_dialog_shown = False
        self._set_modes(False, False, False)
        self._set_indicator_visible(False)