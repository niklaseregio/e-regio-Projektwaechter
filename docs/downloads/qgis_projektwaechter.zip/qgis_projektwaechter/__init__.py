def classFactory(iface):
    from .project_lock import ProjectLockPlugin
    return ProjectLockPlugin(iface)